﻿namespace TFSCommon.Data.Mappings
{
    public class ContractRequirementMectRequirementMap
    {
        public int ContractRequirementContractRequirementId { get; set; }

        public int ParentContractRequirementId { get; set; }

        public int ChildContractRequirementId { get; set; }
    }
}
