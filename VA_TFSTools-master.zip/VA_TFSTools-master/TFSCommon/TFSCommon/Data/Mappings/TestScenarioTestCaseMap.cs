﻿namespace TFSWebApplication.Models.Mappings
{
    public class TestScenarioTestCaseMap
    {
        public int TestScenarioTestCaseId { get; set; }

        public int TestScenarioId { get; set; }

        public int TestCaseId { get; set; }
    }
}
