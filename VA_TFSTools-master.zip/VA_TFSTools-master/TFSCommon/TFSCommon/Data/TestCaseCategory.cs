﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TFSCommon.Data
{
    public class TestCaseCategory
    {
        public TestCaseCategory() { }

        public string Category { get; set; }

        public string TestCasePath { get; set; }
    }


}
