﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TFSCommon.Data;

namespace TFSReporting.ExcelTools
{
    public class UpdateDailyExecutionStatus
    {
        private string _fileName;
        private string _saveLocation;

        private Properties _props;

        private ExcelPackage _excelPackage;
        private ExcelWorkbook _excelWorkbook;

        private ExcelWorksheet _iterationDailyWorksheet;

        private Dictionary<string, List<string>> _folderPathToCategoryMapping;

        public UpdateDailyExecutionStatus(Properties props)
        {
            _fileName = props.FileName;
            _saveLocation = props.SaveLocation;

            _props = props;

            try
            {
                string fileName = _saveLocation + _fileName;
                if (!File.Exists(fileName))
                {
                    throw new FileNotFoundException();
                }

                FileInfo fileInfo;
                if (File.Exists(_saveLocation + "/Updated/" + _fileName))
                {
                    fileInfo = new FileInfo(_saveLocation + "/Updated/" + _fileName);
                }
                else
                {
                    fileInfo = new FileInfo(fileName);
                }

                var newFileInfo = new FileInfo(_saveLocation + "/Updated/" + _fileName);

                _excelPackage = new ExcelPackage(newFileInfo, fileInfo);
                _excelWorkbook = _excelPackage.Workbook;

                ExcelWorksheet iterationPathMappingWorksheet = _excelWorkbook.Worksheets[props.FolderCountsSheetName];

                if (iterationPathMappingWorksheet == null)
                {
                    throw new Exception("Error with Folder Counts sheet.");
                }

                _iterationDailyWorksheet = _excelWorkbook.Worksheets[props.IterationDailySheetName];

                if (_iterationDailyWorksheet == null)
                {
                    throw new Exception("Error with Iteration Daily sheet");
                }

                _folderPathToCategoryMapping = GenerateFolderPathCategoryMapping(iterationPathMappingWorksheet);

                Console.WriteLine("Excel file is opened.");
            }
            catch (Exception e)
            {
                Console.WriteLine("File Location/Name is not valid. Please press Enter and run the program again.");
                Console.Write(e);
                Console.ReadLine();
                Environment.Exit(0);
            }
        }

         

        private  Dictionary<string, List<string>> GenerateFolderPathCategoryMapping(ExcelWorksheet sheet)
        {
            Dictionary<string, List<string>> res = new Dictionary<string, List<string>>();

            int usedRows = 1;
            while (sheet.Cells[usedRows, 11].Value != null)
            {
                usedRows += 1;
            }
            usedRows -= 1;

            for (int i = 2; i <= usedRows; i++)
            {
                if (sheet.Cells[i, 11] != null && sheet.Cells[i, 11].Text != "###")
                {
                    string category = sheet.Cells[i, 11].Value.ToString();
                    Console.WriteLine(category);
                    if (!res.ContainsKey(category))
                    {
                        List<String> newCategory = new List<string>
                        {
                            sheet.Cells[i, 5].Value.ToString()
                        };

                        res[category] = newCategory;
                    }
                    else
                    {
                        res[category].Add(sheet.Cells[i, 5].Value.ToString());
                    }
                }
            }

            return res;
        }
    }
}
