﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TFSCommon.Data;
using Hangfire;

namespace TFSReporting
{
    public interface ITFSReportingJobs
    {
        /// <summary>
        /// Update Execution Input Sheet test case IDs if they do not exist
        /// </summary>
        /// <param name="props">Standard properties read from the config file.</param>
        void UpdateExcelTestCaseId(Properties props);

        /// <summary>
        /// Get test runs from TFS and write to external database. 
        /// </summary>
        /// <param name="props">Standard properties read from the config file.</param>
        void GatherTestRunAndResultsAndWriteToDb(Properties props);

        /// <summary>
        /// Update the Excel Daily Test Case runs between ranges
        /// </summary>
        /// <param name="startDate">First date where you want to start pulling results</param>
        /// <param name="endDate">Last date where you want to pull results</param>
        /// <param name="props">Standard properties read from the config file.</param>
        void UpdateExcelDailyTestCaseRun(string startDate, string endDate, Properties props);

        /// <summary>
        /// Update Test Case Execution sheet with new defects in TFS that are not on the sheet yet. 
        /// </summary>
        /// <param name="props">Standard properties read from the config file.</param>
        void UpdateExcelExecutionInputData(Properties props);

        /// <summary>
        /// Updates the Daily Execution Status with the number of scripts executed per folder/category execution 
        /// </summary>
        void UpdateExcelDailyExecutionStatus();

        /// <summary>
        /// Update the report for Defects and the number of linked test cases. 
        /// Also updates the Test Case With Defects sheet. Shows all Test Cases that are associated to a defect. 
        /// </summary>
        /// <param name="props">Standard properties read from the config file.</param>
        void UpdateExcelDefectWithTestCaseCount(Properties props);
    }
}
