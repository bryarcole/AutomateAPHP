﻿using System;
using System.Collections.Generic;
using TFSCommon.Common;
using TFSCommon.Data;

namespace RequirementsTraceability
{
    class Program
    {
        static void Main(string[] args)
        {
            //string fileName = "Requirement Tracking Report_RTM_Mapping_UPDATED";
            //string fileNameWithExtension = StringTools.addExtension(fileName, "xlsx");

            //if (!System.Diagnostics.Debugger.IsAttached)
            //{
            //    Console.Write("Enter file path: ");
            //    saveLocation = Console.ReadLine();

            //    Console.Write("Enter file name: ");
            //    fileName = Console.ReadLine();
            //    fileNameWithExtension = stringTool.addExtension(fileName, "xlsx");

            //    Console.Write("Enter Start Date: ");
            //    inputtedStartDateTime = Console.ReadLine();

            //    Console.Write("Enter End Date: ");
            //    inputtedEndDateTime = Console.ReadLine();
            //}

            //Logger logger = new Logger();

            PropertiesReader config = new PropertiesReader("config.txt");

            Properties props = new Properties();
            props.PersonalAccessToken = config.get("personalaccesstoken");
            props.TestPlanId = Convert.ToInt32(config.get("testplanid"));
            props.TestSuiteId = Convert.ToInt32(config.get("testsuiteid"));
            props.Project = config.get("project");
            props.Uri = config.get("server");
            props.SaveLocation = config.get("saveLocation");
            props.FileName = StringTools.addExtension(config.get("fileName"), "xlsx"); ;
            props.ExecutionSheetName = config.get("executionsheetname");
            props.ScriptSheetName = config.get("scriptsheetname");
            props.TestPlanId = Convert.ToInt32(config.get("testplanid"));
            props.TestSuiteId = Convert.ToInt32(config.get("testsuiteid"));

            Logger logger = new Logger(props.SaveLocation);

            props.Logger = logger;

            IRequirementsTracabilityJobs requirementsTracabilityJobs = new RequirementsTraceabilityJobs(props);

            //requirementsTracabilityJobs.UpdateContractRequirementsAndAllLinks(props);

            //GetWorkItemType workItem = new GetWorkItemType(props);

            //List<ContractRequirement> contractRequirements = workItem.GetContractRequirements();
            ////Console.WriteLine("Hello");

            //ContractRequirementUpdate update = new ContractRequirementUpdate(props);
            //update.UpdateScenarioSheet(contractRequirements);
            //update.ExcelCleanup();

            //requirementsTracabilityJobs.CreateAndUpdateTestScenarios();

            //List<ContractRequirement> requirements = requirementsTracabilityJobs.GatherAndWriteContractRequirementToDb();

            //requirementsTracabilityJobs.GatherAndWriteContractRequirementsToDb(requirements);

            //requirementsTracabilityJobs.GatherAndWriteContractMectRequirementMappingToDb();

            //requirementsTracabilityJobs.GatherAndWriteMectRequirementToDb();

            requirementsTracabilityJobs.UpdateTestsCasesInDB();

            TestCase singleTestCase = requirementsTracabilityJobs.GetSingleTestCase(12345, 12344);

            //requirementsTracabilityJobs.GetTestCasesInSuite();

            //requirementsTracabilityJobs.UpdateMectAndContractRequirementIdsToExcel();

            //requirementsTracabilityJobs.DeleteNonExistingTestsCases(null);

            Console.WriteLine("All Tasks are done... ");
            Console.ReadLine();
        }
    }
}
