﻿namespace RequirementsTraceability.TFSTools
{
    public interface ITfsTools
    {
    }
}
