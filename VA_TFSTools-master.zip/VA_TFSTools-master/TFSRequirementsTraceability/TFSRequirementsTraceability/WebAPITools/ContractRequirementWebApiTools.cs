﻿namespace RequirementsTraceability.WebAPITools
{
    public class ContractRequirementWebApiTools
    {
    }
}
