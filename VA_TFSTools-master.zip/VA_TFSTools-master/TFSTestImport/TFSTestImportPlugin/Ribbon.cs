﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;

namespace TFSTestImportPlugin
{
    public partial class Ribbon
    {
        private void Ribbon_Load(object sender, RibbonUIEventArgs e)
        {

        }

        private void TFSImportButton_Click(object sender, RibbonControlEventArgs e)
        {

        }
    }
}
