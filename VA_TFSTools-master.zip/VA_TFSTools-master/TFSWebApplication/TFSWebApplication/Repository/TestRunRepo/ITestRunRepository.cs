﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TFSCommon.Data;

namespace TFSWebApplication.Repository.TestRunRepo
{
    public interface ITestRunRepository: IGenericRepository<TestRun>
    {
    }
}
